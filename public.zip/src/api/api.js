import API from "./axiosInstance";

// 🟩 Register User
export const registerUser = async (userData) => {
  try {    const { data } = await API.post("/users/register", userData);

    return { success: true, data };
  } catch (error) {
    console.error("Register error:", error);
    return {
      success: false,
      error: error.response?.data?.message || error.message,
    };
  }
};

// 🟩 Login User
export const loginUser = async (userData) => {
  try {
    const { data } = await API.post("/users/login", userData);
    return { success: true, data };
  } catch (error) {
    console.error("Login error:", error);
    return {
      success: false,
      error: error.response?.data?.message || error.message,
    };
  }
};

// 🟩 Get User Profile
export const getProfile = async () => {
  try {
    const { data } = await API.get("/users/profile");
    return { success: true, data };
  } catch (error) {
    console.error("Get profile error:", error);
    return {
      success: false,
      error: error.response?.data?.message || error.message,
    };
  }
};

// 🟩 Update User Profile (with FormData)
export const updateProfile = async (formData) => {
  try {
    // Debug log for development (safe)
    for (let [key, value] of formData.entries()) {
      console.log(`FormData → ${key}:`, value instanceof File ? value.name : value);
    }

    const { data } = await API.put("/users/updateProfile", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    console.log("✅ Profile update success:", data);
    return { success: true, data };
  } catch (error) {
    console.error("🚨 Profile update error:", error);
    return {
      success: false,
      error: error.response?.data?.message || error.message,
    };
  }
};

// 🟩 Delete Account
export const deleteAccount = async () => {
  try {
    const { data } = await API.delete("/users/delete");
    return { success: true, data };
  } catch (error) {
    console.error("Delete account error:", error);
    return {
      success: false,
      error: error.response?.data?.message || error.message,
    };
  }
};
