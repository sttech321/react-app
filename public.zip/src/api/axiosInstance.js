// src/api/axiosInstance.js
import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api", // change if needed
});

// ✅ Attach token to every request
API.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ✅ Handle expired or invalid tokens globally
API.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.message || "";

    if (
      error.response?.status === 401 &&
      (message.includes("expired") ||
        message.includes("Invalid") ||
        message.includes("No token"))
    ) {
      localStorage.removeItem("token");
      // optional: clear any user context here
      window.location.href = "/login"; // redirect user
    }

    return Promise.reject(error);
  }
);

export default API;
